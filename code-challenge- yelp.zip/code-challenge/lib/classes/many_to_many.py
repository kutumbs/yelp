class Customer:
    all = []

    def __init__(self, first_name, last_name):
        self._first_name = None
        self._last_name = None
        self.first_name = first_name
        self.last_name = last_name
        self._reviews = []
        self.all.append(self)


    @property
    def first_name(self):
        return self._first_name

    @first_name.setter
    def first_name(self, value):
        if isinstance(value, str) and 1 <= len(value) <= 25:
            self._first_name = value
        else:
            raise ValueError("First name must be a string of length 1 to 25")

    @property
    def last_name(self):
        return self._last_name

    @last_name.setter
    def last_name(self, value):
        if isinstance(value, str) and 1 <= len(value) <= 25:
            self._last_name = value
        else:
            raise ValueError("Last name must be a string of length 1 to 25")

    def add_review(self, review):
        self._reviews.append(review)

    def reviews(self):
        return self._reviews

    def restaurants(self):
        return list({review.restaurant for review in self._reviews})

    def num_negative_reviews(self):
        return len([review for review in self._reviews if review.rating <= 2])

    def has_reviewed_restaurant(self, restaurant):
        return any(review.restaurant == restaurant for review in self._reviews)

    @classmethod
    def top_negative_reviewer(cls):
        top_reviewer = None
        most_negative_reviews = 0
        for customer in cls.all:
            negative_reviews = customer.num_negative_reviews()
            if negative_reviews > most_negative_reviews:
                most_negative_reviews = negative_reviews
                top_reviewer = customer
        return top_reviewer


class Restaurant:
    all = []

    def __init__(self, name):
        self._name = None
        self.name = name
        self._reviews = []
        self.all.append(self)

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        if isinstance(value, str) and len(value) >= 1:
            self._name = value
        else:
            raise ValueError("Restaurant name must be a non-empty string")

    def add_review(self, review):
        self._reviews.append(review)

    def reviews(self):
        return self._reviews

    def customers(self):
        return list({review.customer for review in self._reviews})

    def average_star_rating(self):
        if not self._reviews:
            return 0.0
        
        total_ratings = sum(review.rating for review in self._reviews)
        num_reviews = len(self._reviews)
        average_rating = round(total_ratings / num_reviews, 1)
        return average_rating

    @classmethod
    def top_two_restaurants(cls):
        if not cls.all:
            return None

        sorted_restaurants = sorted(cls.all, key=lambda restaurant: restaurant.average_star_rating(), reverse=True)
        top_two = sorted_restaurants[:2]
        return top_two


class Review:
    all = []

    def __init__(self, customer, restaurant, rating):
        self.customer = customer
        self.restaurant = restaurant
        self._rating = None
        self.set_rating(rating)  # Call the method to set rating
        customer.add_review(self)
        restaurant.add_review(self)
        self.all.append(self)

    @property
    def rating(self):
        return self._rating

    def set_rating(self, value):  # Modified to allow rating change
        if isinstance(value, int) and 1 <= value <= 5:
            self._rating = value
        else:
            raise ValueError("Rating must be an integer between 1 and 5")
