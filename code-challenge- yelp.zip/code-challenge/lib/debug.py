#!/usr/bin/env python3
import ipdb

from classes.many_to_many import Customer
from classes.many_to_many import Restaurant
from classes.many_to_many import Review

if __name__ == '__main__':
    print("HELLO! :) let's debug :vibing_potato:")
    
    # don't remove this line, it's for debugging!
    ipdb.set_trace()
